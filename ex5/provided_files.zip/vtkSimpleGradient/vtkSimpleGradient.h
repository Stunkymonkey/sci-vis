#pragma once

#include "vtkSimpleImageToImageFilter.h"

/// <summary>
/// Simple Gradient plugin derived from VTK class
/// </summary>
class vtkSimpleGradient : public vtkSimpleImageToImageFilter
{
public:
	static vtkSimpleGradient *New();
	vtkTypeMacro(vtkSimpleGradient, vtkSimpleImageToImageFilter);

	/// <summary>
	/// Function executed by ParaView when requesting data
	/// </summary>
	void SimpleExecute(vtkImageData*, vtkImageData*);
};
