#pragma once

#include "vtkSmartPointer.h"
#include "vtkTextSource.h"

class vtkInformation;
class vtkInformationVector;

class vtkDisplayNumber : public vtkTextSource
{
public:
	static vtkDisplayNumber *New();
	vtkTypeMacro(vtkDisplayNumber, vtkTextSource);
	
	// Setter and getter for the Matrikel number value
	vtkSetStringMacro(Matrikel);
	vtkGetStringMacro(Matrikel);
	
	// Main function for requesting data
	int RequestData (vtkInformation *request, vtkInformationVector **input, vtkInformationVector *outputVector);

protected:
	vtkDisplayNumber();
	~vtkDisplayNumber();

private:
	// Keep the Matrikel number stored
	char* Matrikel;
};