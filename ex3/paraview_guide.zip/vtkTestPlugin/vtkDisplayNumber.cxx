#include "vtkObjectFactory.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkSmartPointer.h"

#include "vtkDisplayNumber.h"

vtkStandardNewMacro(vtkDisplayNumber);

vtkDisplayNumber::vtkDisplayNumber()
{
	this->Matrikel = nullptr;
}

vtkDisplayNumber::~vtkDisplayNumber()
{
}

int vtkDisplayNumber::RequestData(vtkInformation *request, vtkInformationVector **input, vtkInformationVector *outputVector) {
	// Set text for the Matrikel number set by the user
	std::string prefixed = std::string("MatNr:") + this->Matrikel;
	
	this->BackingOff();
	this->SetText(prefixed.c_str());
	
	// Relay request to parent
	vtkTextSource::RequestData(request, input, outputVector);
	
	return 1;
}
